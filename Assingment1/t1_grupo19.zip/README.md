
- Name: Lucas Corlete Alves de Melo - NUSP: 13676461; Jean Carlos Pereira Cassiano - NUSP: 138640008
- Course: SCC0607 - Estrutura de Dados III
- Professor: Cristina Dutra de Aguiar
- Project: Trabalho Introdutório
- Description: **Este trabalho tem como objetivo armazenar dados em um arquivo binário bem como desenvolver funcionalidades para a manipulação desses dados. Novas funcionalidades serão adicionadas conforme o avançar da disciplina.**

