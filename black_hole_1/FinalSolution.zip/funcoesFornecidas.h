
void binarioNaTela(char *nomeArquivoBinario);